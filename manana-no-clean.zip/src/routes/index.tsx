import { createFileRoute } from "@tanstack/react-router";
import { HomeScreen } from "@/components/desk/home-screen";

export const Route = createFileRoute("/")({ component: HomeScreen });
