import { createFileRoute, Link } from "@tanstack/react-router";
import { CaseScreen } from "@/components/desk/case-screen";
import { getTramite } from "@/data/tramites";

export const Route = createFileRoute("/t/$id")({
  component: CasePage,
});

function CasePage() {
  const { id } = Route.useParams();
  const tramite = getTramite(id);
  if (!tramite) {
    return (
      <main className="mx-auto max-w-xl px-4 py-16">
        <h1 className="font-serif text-3xl">Ese trámite no está en el mostrador</h1>
        <Link to="/" className="mt-4 inline-flex min-h-11 items-center font-medium text-seal">
          Volver
        </Link>
      </main>
    );
  }
  return <CaseScreen key={tramite.id} tramite={tramite} />;
}
