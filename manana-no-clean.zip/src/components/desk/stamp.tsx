import type { Level } from "@/data/types";

const FACE: Record<Level, { ring: string; ink: string; kicker: string; wash: string }> = {
  go: { ring: "border-go", ink: "text-go", kicker: "En regla", wash: "bg-go-soft" },
  almost: { ring: "border-wait", ink: "text-wait", kicker: "Casi", wash: "bg-wait-soft" },
  back: { ring: "border-back", ink: "text-back", kicker: "Vuelve mañana", wash: "bg-back-soft" },
};

export function Stamp({ level, headline }: { level: Level; headline: string }) {
  const face = FACE[level];
  return (
    <div className={`inline-flex -rotate-6 ${face.ink}`} aria-hidden>
      <div className={`grid size-40 place-items-center rounded-full border-4 border-double ${face.ring} ${face.wash} sm:size-44`}>
        <div className={`grid size-32 place-items-center rounded-full border ${face.ring} sm:size-36`}>
          <div className="px-4 text-center">
            <p className="text-xs font-semibold uppercase tracking-widest">{face.kicker}</p>
            <p className="mt-1 font-serif text-xl leading-tight">{headline}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export function LevelDot({ level }: { level: Level }) {
  const tone = level === "go" ? "bg-go" : level === "almost" ? "bg-wait" : "bg-back";
  return <span className={`inline-block size-2.5 rounded-full ${tone}`} />;
}
