import { useEffect } from "react";
import { useDesk } from "@/lib/desk-store";

export function DeskHydrator() {
  useEffect(() => {
    void useDesk.persist.rehydrate();
  }, []);
  return null;
}
