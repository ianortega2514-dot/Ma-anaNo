import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, Check, ExternalLink } from "lucide-react";
import type { Answers, Fit, Tramite } from "@/data/types";
import { applicableDocs, caseSummary, isBlocking, verdict } from "@/lib/engine";
import { useDesk } from "@/lib/desk-store";
import { explainCase } from "@/lib/ai.functions";
import { Stamp } from "@/components/desk/stamp";

export function CaseScreen({ tramite }: { tramite: Tramite }) {
  const saveCase = useDesk((state) => state.saveCase);
  const [answers, setAnswers] = useState<Answers>({});
  const [have, setHave] = useState<Record<string, boolean>>({});
  const [qIndex, setQIndex] = useState(0);
  const [phase, setPhase] = useState<"ask" | "result">("ask");
  const [savedNote, setSavedNote] = useState("");
  const [aiText, setAiText] = useState("");
  const [aiError, setAiError] = useState("");
  const [aiPending, setAiPending] = useState(false);
  const [ready, setReady] = useState(false);
  const told = useRef<Record<string, string>>({});

  useEffect(() => {
    document.title = `${tramite.name} · MañanaNo`;
  }, [tramite.name]);

  useEffect(() => {
    let alive = true;
    void Promise.resolve(useDesk.persist.rehydrate()).then(() => {
      if (!alive) return;
      const saved = useDesk.getState().cases.find((item) => item.tramiteId === tramite.id);
      if (saved) {
        setAnswers(saved.answers);
        setHave(saved.have);
        setPhase("result");
      }
      setReady(true);
    });
    return () => {
      alive = false;
    };
  }, [tramite.id]);

  const visible = tramite.questions.filter((question) => !question.when || question.when(answers));
  const question = visible[Math.min(qIndex, Math.max(visible.length - 1, 0))];
  const result = useMemo(() => verdict(tramite, answers, have), [tramite, answers, have]);
  const docs = applicableDocs(tramite, answers);
  const warnings = tramite.warnings(answers);
  const summary = caseSummary(tramite, answers);

  function choose(optionId: string) {
    if (!question) return;
    const next = { ...answers, [question.id]: optionId };
    setAnswers(next);
    setSavedNote("");
    setAiText("");
    const nextVisible = tramite.questions.filter((item) => !item.when || item.when(next));
    const pos = nextVisible.findIndex((item) => item.id === question.id);
    if (pos < nextVisible.length - 1) setQIndex(pos + 1);
    else setPhase("result");
  }

  function back() {
    if (phase === "result") {
      setPhase("ask");
      setQIndex(Math.max(visible.length - 1, 0));
      return;
    }
    setQIndex((index) => Math.max(0, index - 1));
  }

  function reset() {
    setAnswers({});
    setHave({});
    setQIndex(0);
    setPhase("ask");
    setSavedNote("");
    setAiText("");
    setAiError("");
  }

  async function tell() {
    const best = [tramite.online, tramite.desk].find((channel) => channel.fit(answers) === "best");
    const payload = {
      name: tramite.name,
      level: result.level,
      headline: result.headline,
      reason: result.reason,
      summary,
      missing: result.missing.map((doc) => doc.label),
      ready: result.ready.map((doc) => doc.label),
      warnings,
      channel: best ? `${best.title}. ${best.note}` : "",
    };
    const key = JSON.stringify(payload);
    const cached = told.current[key];
    if (cached) {
      setAiText(cached);
      setAiError("");
      return;
    }
    setAiPending(true);
    setAiError("");
    const response = await explainCase({ data: payload });
    setAiPending(false);
    if (!response.ok) {
      setAiError(response.error);
      return;
    }
    told.current[key] = response.text;
    setAiText(response.text);
  }

  return (
    <main className="mx-auto min-h-dvh w-full max-w-3xl px-4 pb-20 pt-6 sm:px-6">
      <header className="flex items-center justify-between gap-3">
        <Link to="/" className="font-serif text-2xl tracking-tight">
          Mañana<span className="text-seal">No</span>
        </Link>
        <p className="text-xs font-medium uppercase tracking-widest text-muted">Expediente</p>
      </header>

      <div className="mt-6">
        <p className="text-xs font-medium uppercase tracking-widest text-muted">{tramite.organism}</p>
        <h1 className="mt-1 font-serif text-4xl leading-tight">{tramite.name}</h1>
        <p className="mt-2 text-muted">{tramite.blurb}</p>
      </div>

      {!ready && <p className="mt-8 text-sm text-muted">Abriendo el expediente…</p>}

      {ready && phase === "ask" && question && (
        <section className="mt-8">
          <p className="text-sm font-medium text-seal">
            Pregunta {Math.min(qIndex + 1, visible.length)} de {visible.length}
          </p>
          <h2 className="mt-2 font-serif text-3xl leading-tight">{question.prompt}</h2>
          {question.hint && <p className="mt-2 text-sm leading-relaxed text-muted">{question.hint}</p>}
          <div className="mt-5 grid gap-3">
            {question.options.map((option) => {
              const selected = answers[question.id] === option.id;
              return (
                <button
                  key={option.id}
                  type="button"
                  onClick={() => choose(option.id)}
                  className={`min-h-14 rounded-2xl border px-4 py-3 text-left ${
                    selected ? "border-seal bg-back-soft" : "border-line bg-sheet"
                  }`}
                >
                  <span className="block font-medium">{option.label}</span>
                  {option.detail && <span className="mt-1 block text-sm text-muted">{option.detail}</span>}
                </button>
              );
            })}
          </div>
          {qIndex > 0 && (
            <button type="button" onClick={back} className="mt-4 inline-flex min-h-11 items-center gap-2 text-sm font-medium">
              <ArrowLeft className="size-4" aria-hidden />
              Anterior
            </button>
          )}
        </section>
      )}

      {ready && phase === "result" && (
        <section className="mt-8">
          <div className="rounded-2xl border border-line bg-sheet px-4 py-6 sm:px-6">
            <div className="flex flex-col items-center text-center">
              <Stamp level={result.level} headline={result.headline} />
              <p className="sr-only">
                {result.level === "go" ? "En regla" : result.level === "almost" ? "Casi" : "Te devuelven"}.{" "}
                {result.headline}
              </p>
              <p className="mt-6 max-w-lg text-lg leading-relaxed">{result.reason}</p>
              {summary && <p className="mt-3 text-sm text-muted">{summary}</p>}
              {result.blocked && result.level === "back" && (
                <p className="mt-3 text-sm font-medium text-back">Esto no se arregla marcando más papeles.</p>
              )}
            </div>
          </div>

          {warnings.length > 0 && (
            <ul className="mt-4 space-y-2">
              {warnings.map((warning) => (
                <li key={warning} className="rounded-2xl border border-wait bg-wait-soft px-4 py-3 text-sm leading-relaxed text-wait">
                  {warning}
                </li>
              ))}
            </ul>
          )}

          <div className="mt-8 flex items-end justify-between gap-3">
            <h2 className="font-serif text-2xl">Lo que llevas</h2>
            <p className="text-sm text-muted">
              {result.ready.length} de {docs.length}
            </p>
          </div>
          <p className="mt-1 text-sm text-muted">Márcalo. El sello de arriba cambia solo.</p>
          <ul className="mt-4 grid gap-2">
            {docs.map((doc) => {
              const on = Boolean(have[doc.id]);
              const blocking = isBlocking(doc, answers);
              return (
                <li key={doc.id}>
                  <button
                    type="button"
                    aria-pressed={on}
                    onClick={() => {
                      setHave((current) => ({ ...current, [doc.id]: !current[doc.id] }));
                      setSavedNote("");
                    }}
                    className={`flex w-full items-start gap-3 rounded-2xl border px-4 py-3 text-left ${
                      on ? "border-go bg-go-soft" : "border-line bg-sheet"
                    }`}
                  >
                    <span
                      className={`mt-0.5 grid size-7 shrink-0 place-items-center rounded-full border ${
                        on ? "border-go bg-go text-seal-ink" : "border-line bg-sheet text-transparent"
                      }`}
                    >
                      <Check className="size-4" aria-hidden />
                    </span>
                    <span>
                      <span className="block font-medium">{doc.label}</span>
                      <span className="mt-1 block text-sm leading-relaxed text-muted">{doc.why}</span>
                      <span className="mt-2 block text-xs font-semibold uppercase tracking-widest text-muted">
                        {blocking ? "Si falta, te pueden devolver" : "Útil, no suele bastar para devolverte"}
                      </span>
                    </span>
                  </button>
                </li>
              );
            })}
          </ul>

          <h2 className="mt-8 font-serif text-2xl">Por dónde ir</h2>
          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <ChannelCard fit={tramite.online.fit(answers)} title={tramite.online.title} where={tramite.online.where} time={tramite.online.time} note={tramite.online.note} kind="Internet" />
            <ChannelCard fit={tramite.desk.fit(answers)} title={tramite.desk.title} where={tramite.desk.where} time={tramite.desk.time} note={tramite.desk.note} kind="En persona" />
          </div>

          <div className="mt-4 grid gap-3 sm:grid-cols-2">
            <p className="rounded-2xl border border-line bg-sheet px-4 py-3 text-sm">
              <span className="block text-xs font-semibold uppercase tracking-widest text-muted">Cuánto cuesta</span>
              <span className="mt-1 block leading-relaxed">{tramite.fee}</span>
            </p>
            <p className="rounded-2xl border border-line bg-sheet px-4 py-3 text-sm">
              <span className="block text-xs font-semibold uppercase tracking-widest text-muted">Plazo</span>
              <span className="mt-1 block leading-relaxed">{tramite.plazo}</span>
            </p>
          </div>

          <h2 className="mt-8 font-serif text-2xl">El orden</h2>
          <ol className="mt-4 space-y-3">
            {tramite.steps.map((step, index) => (
              <li key={step.title} className="flex gap-3">
                <span className="grid size-8 shrink-0 place-items-center rounded-full bg-ink font-medium text-seal-ink">
                  {index + 1}
                </span>
                <span>
                  <span className="block font-medium">{step.title}</span>
                  <span className="mt-1 block text-sm leading-relaxed text-muted">{step.detail}</span>
                </span>
              </li>
            ))}
          </ol>

          <h2 className="mt-8 font-serif text-2xl">Qué decir</h2>
          <ul className="mt-4 space-y-2">
            {tramite.script(answers).map((line) => (
              <li key={line} className="rounded-2xl border border-line bg-sheet px-4 py-3 text-sm leading-relaxed">
                “{line}”
              </li>
            ))}
          </ul>

          <h2 className="mt-8 font-serif text-2xl">Por qué te devuelven</h2>
          <ul className="mt-4 grid gap-3">
            {tramite.rejections.map((item) => (
              <li key={item.title} className="rounded-2xl border border-line bg-sheet px-4 py-3">
                <p className="font-medium">{item.title}</p>
                <p className="mt-1 text-sm leading-relaxed text-muted">{item.detail}</p>
              </li>
            ))}
          </ul>

          <div className="mt-8 rounded-2xl border border-line bg-sheet p-4">
            <h2 className="font-serif text-2xl">Cuéntamelo en cristiano</h2>
            <p className="mt-1 text-sm leading-relaxed text-muted">
              Lo cuenta con tus datos de arriba. No puede añadir papeles que el sello no tenga.
            </p>
            <button
              type="button"
              onClick={() => void tell()}
              disabled={aiPending}
              className="mt-4 min-h-12 rounded-full bg-seal px-5 font-medium text-seal-ink disabled:opacity-60"
            >
              {aiPending ? "Está mirando tu expediente…" : aiText ? "Volver a contarlo" : "Contarlo con mis datos"}
            </button>
            {aiError && <p className="mt-3 text-sm text-back">{aiError}</p>}
            {aiText && <p className="mt-4 whitespace-pre-wrap text-base leading-relaxed">{aiText}</p>}
          </div>

          {tramite.officialUrl && (
            <a
              href={tramite.officialUrl}
              target="_blank"
              rel="noreferrer"
              className="mt-4 inline-flex min-h-11 items-center gap-2 text-sm font-medium text-seal"
            >
              {tramite.officialLabel ?? "Sede oficial"}
              <ExternalLink className="size-4" aria-hidden />
            </a>
          )}

          <div className="mt-8 flex flex-wrap gap-3">
            <button
              type="button"
              onClick={() => {
                saveCase({
                  id: tramite.id,
                  tramiteId: tramite.id,
                  answers,
                  have,
                  savedAt: Date.now(),
                });
                setSavedNote("Guardado en este dispositivo.");
              }}
              className="min-h-12 rounded-full bg-ink px-5 font-medium text-seal-ink"
            >
              Guardar expediente
            </button>
            <button type="button" onClick={back} className="min-h-12 rounded-full border border-line bg-sheet px-5 font-medium">
              Cambiar respuestas
            </button>
            <button type="button" onClick={reset} className="min-h-12 px-2 text-sm font-medium text-muted">
              Empezar de cero
            </button>
          </div>
          {savedNote && <p className="mt-3 text-sm text-go">{savedNote}</p>}

          <p className="mt-8 text-sm leading-relaxed text-muted">
            Orientación para no ir a ciegas. La sede del organismo manda si una tasa, un plazo o una cita han cambiado.
          </p>
        </section>
      )}
    </main>
  );
}

function ChannelCard({
  fit,
  kind,
  title,
  where,
  time,
  note,
}: {
  fit: Fit;
  kind: string;
  title: string;
  where: string;
  time: string;
  note: string;
}) {
  const badge = fit === "best" ? "Haz este" : fit === "ok" ? "También vale" : "No sirve para hacerlo";
  const tone =
    fit === "best" ? "border-go bg-go-soft" : fit === "no" ? "border-line bg-paper text-muted" : "border-line bg-sheet";
  return (
    <article className={`rounded-2xl border p-4 ${tone}`}>
      <p className="text-xs font-semibold uppercase tracking-widest">{badge}</p>
      <h3 className="mt-2 font-serif text-xl text-ink">{title}</h3>
      <p className="mt-1 text-xs font-medium uppercase tracking-widest text-muted">
        {kind} · {time}
      </p>
      <p className="mt-2 text-sm font-medium text-ink">{where}</p>
      <p className="mt-2 text-sm leading-relaxed text-muted">{note}</p>
    </article>
  );
}
