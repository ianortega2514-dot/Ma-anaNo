import { useEffect, useState } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import { ArrowRight, Search, Trash2 } from "lucide-react";
import { rankTramites, TRAMITES, getTramite } from "@/data/tramites";
import { caseSummary, verdict } from "@/lib/engine";
import { useDesk } from "@/lib/desk-store";
import { routeCase } from "@/lib/ai.functions";
import { LevelDot } from "@/components/desk/stamp";

export function HomeScreen() {
  const navigate = useNavigate();
  const cases = useDesk((state) => state.cases);
  const removeCase = useDesk((state) => state.removeCase);
  const [ready, setReady] = useState(false);
  const [query, setQuery] = useState("");
  const [routing, setRouting] = useState(false);
  const [routeError, setRouteError] = useState("");

  useEffect(() => {
    const unsub = useDesk.persist.onFinishHydration(() => setReady(true));
    if (useDesk.persist.hasHydrated()) setReady(true);
    return () => {
      unsub();
    };
  }, []);

  const matches = rankTramites(query).slice(0, 4);
  const saved = ready ? cases : [];

  async function askDesk() {
    setRouting(true);
    setRouteError("");
    const result = await routeCase({ data: { text: query } });
    setRouting(false);
    if (!result.ok) {
      setRouteError(result.error);
      return;
    }
    await navigate({ to: "/t/$id", params: { id: result.id } });
  }

  return (
    <main className="mx-auto min-h-dvh w-full max-w-3xl px-4 pb-16 pt-6 sm:px-6">
      <header className="flex items-center justify-between gap-4">
        <p className="font-serif text-2xl tracking-tight">
          Mañana<span className="text-seal">No</span>
        </p>
        <p className="text-xs font-medium uppercase tracking-widest text-muted">Mostrador · España</p>
      </header>

      <section className="mt-10 border-t-4 border-seal pt-6">
        <p className="text-sm font-medium text-seal">Sello de ventanilla</p>
        <h1 className="mt-2 max-w-xl font-serif text-4xl leading-tight sm:text-5xl">
          Si vas así, vuelves mañana.
        </h1>
        <p className="mt-4 max-w-xl text-lg leading-relaxed text-muted">
          Otras inteligencias te escriben un párrafo que suena oficial. Esto monta tu expediente y cambia el
          sello según los papeles que ya tienes.
        </p>
      </section>

      <form
        className="mt-8"
        onSubmit={(event) => {
          event.preventDefault();
          if (matches[0]) {
            void navigate({ to: "/t/$id", params: { id: matches[0].id } });
            return;
          }
          if (query.trim().length > 3) void askDesk();
        }}
      >
        <label className="block text-sm font-medium" htmlFor="busca">
          ¿Qué tienes que hacer?
        </label>
        <div className="mt-2 flex items-center gap-2 rounded-2xl border border-line bg-sheet px-3">
          <Search className="size-5 shrink-0 text-muted" aria-hidden />
          <input
            id="busca"
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setRouteError("");
            }}
            placeholder="Se me caduca el DNI, quiero el paro, me mudo…"
            className="h-12 w-full bg-transparent text-base outline-none placeholder:text-muted"
          />
        </div>
        {query.trim().length > 1 && (
          <div className="mt-2 overflow-hidden rounded-2xl border border-line bg-sheet">
            {matches.length === 0 && (
              <p className="px-4 py-3 text-sm text-muted">Ningún trámite del mostrador se llama así.</p>
            )}
            {matches.map((tramite) => (
              <Link
                key={tramite.id}
                to="/t/$id"
                params={{ id: tramite.id }}
                className="flex items-center justify-between gap-3 border-b border-line px-4 py-3 last:border-b-0"
              >
                <span>
                  <span className="block font-medium">{tramite.name}</span>
                  <span className="block text-sm text-muted">{tramite.short}</span>
                </span>
                <ArrowRight className="size-4 shrink-0 text-muted" aria-hidden />
              </Link>
            ))}
            <button
              type="button"
              onClick={() => void askDesk()}
              disabled={routing || query.trim().length < 4}
              className="flex min-h-12 w-full items-center justify-between px-4 py-3 text-left text-sm font-medium text-seal disabled:opacity-50"
            >
              {routing ? "Mirando de qué trámite se trata…" : "Que lo encaje, si no está en la lista"}
              <ArrowRight className="size-4" aria-hidden />
            </button>
          </div>
        )}
        {routeError && <p className="mt-2 text-sm text-back">{routeError}</p>}
      </form>

      <section className="mt-10">
        <h2 className="font-serif text-2xl">En el mostrador</h2>
        <ul className="mt-4 grid gap-3 sm:grid-cols-2">
          {TRAMITES.map((tramite) => (
            <li key={tramite.id}>
              <Link
                to="/t/$id"
                params={{ id: tramite.id }}
                className="flex h-full flex-col rounded-2xl border border-line bg-sheet p-4"
              >
                <span className="text-xs font-medium uppercase tracking-widest text-muted">{tramite.organism}</span>
                <span className="mt-2 font-serif text-2xl leading-tight">{tramite.name}</span>
                <span className="mt-2 flex-1 text-sm leading-relaxed text-muted">{tramite.blurb}</span>
                <span className="mt-4 inline-flex items-center gap-1 text-sm font-medium text-seal">
                  Montar el expediente
                  <ArrowRight className="size-4" aria-hidden />
                </span>
              </Link>
            </li>
          ))}
        </ul>
      </section>

      <section className="mt-10 rounded-2xl border border-line bg-sheet p-5">
        <h2 className="font-serif text-2xl">En qué no es un chat</h2>
        <dl className="mt-4 divide-y divide-line">
          {[
            ["Te redacta un texto", "Te pone un sello: puedes ir, te falta una cosa, o te devuelven"],
            ["Puede inventarse un papel", "Solo salen los de ese trámite, y cambian con tu caso"],
            ["No sabe lo que ya llevas", "Lo marcas. El sello se mueve"],
            ["Suena igual en cualquier país", "Está escrito para ventanillas de España"],
          ].map(([chat, here]) => (
            <div key={chat} className="grid gap-1 py-3 sm:grid-cols-2 sm:gap-6">
              <dt className="text-sm text-muted">{chat}</dt>
              <dd className="text-sm font-medium">{here}</dd>
            </div>
          ))}
        </dl>
      </section>

      {saved.length > 0 && (
        <section className="mt-10">
          <h2 className="font-serif text-2xl">Tus expedientes</h2>
          <p className="mt-1 text-sm text-muted">Guardados en este dispositivo.</p>
          <ul className="mt-4 space-y-3">
            {saved.map((item) => {
              const tramite = getTramite(item.tramiteId);
              if (!tramite) return null;
              const result = verdict(tramite, item.answers, item.have);
              return (
                <li key={item.id} className="flex items-stretch gap-2">
                  <Link
                    to="/t/$id"
                    params={{ id: item.tramiteId }}
                    className="flex min-w-0 flex-1 items-center justify-between gap-3 rounded-2xl border border-line bg-sheet px-4 py-3"
                  >
                    <span className="min-w-0">
                      <span className="flex items-center gap-2 font-medium">
                        <LevelDot level={result.level} />
                        {tramite.name}
                      </span>
                      <span className="mt-1 block truncate text-sm text-muted">
                        {caseSummary(tramite, item.answers) || result.headline}
                      </span>
                    </span>
                    <ArrowRight className="size-4 shrink-0 text-muted" aria-hidden />
                  </Link>
                  <button
                    type="button"
                    aria-label={`Quitar ${tramite.name}`}
                    onClick={() => removeCase(item.id)}
                    className="grid w-12 shrink-0 place-items-center rounded-2xl border border-line bg-sheet text-muted"
                  >
                    <Trash2 className="size-4" aria-hidden />
                  </button>
                </li>
              );
            })}
          </ul>
        </section>
      )}

      <footer className="mt-12 border-t border-line pt-4 text-sm leading-relaxed text-muted">
        Orientación para llegar preparado. No sustituye a la sede del organismo: tasas, citas y plazos cambian.
      </footer>
    </main>
  );
}
